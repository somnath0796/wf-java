package threads;

public class ThreadDemo1 {

	public static void main(String[] args) {
		MyThread t1 = new MyThread();
		MyThread t2 = new MyThread();
		t1.setName("Rajini");
		t2.setName("Robot");
		t1.start();
		t2.start();
		
		//t1.start();

	}

}
