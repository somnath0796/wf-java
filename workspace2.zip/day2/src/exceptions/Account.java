package exceptions;

public class Account {
	private double balance;

	public double deposit(double amount) {
		balance = balance + amount;
		return balance;
	}

	public double withdraw(double amount) throws LowBalanceException{
		try {
			if (balance < amount) {
				throw new LowBalanceException("You Have Low Balance..");
			} else {
				balance = balance - amount;
			}
		} catch (LowBalanceException e) {
			System.out.println(e.getMessage());
			throw e;
		}
		return balance;
	}
}
