package exceptions;

public class LowBalanceException extends Exception {

	public LowBalanceException(String message) {
		super(message);
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Your Balance is Low";
	}
}
