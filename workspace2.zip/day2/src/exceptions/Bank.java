package exceptions;

public class Bank {

	public static void main(String[] args) {
		Account acc = new Account();
		System.out.println(acc.deposit(2000));
		try {
			System.out.println(acc.withdraw(2001));
		} catch (LowBalanceException e) {
			e.printStackTrace();
		}

	}

}
