package exceptions;

public class Demo1 {

	public static void main(String[] args) {
		try {
			int a = 10;
			int b = 10;
			double d = a / b;
			int[] nums = new int[4];
			nums[2] = 20;
			String[] names = new String[5];
			//names[3].equals("hello");
			System.out.println("No Exceptions");
		}catch (ArithmeticException e) {
			e.printStackTrace();
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Exception : " + e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			System.out.println("this is finally block..");
		}
		System.out.println("I am OK Now..");

	}

}
