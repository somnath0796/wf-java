package interfaces;

public class OracleDB implements Connection {

	public String getConnection() {
		return "Oracle Database Connected";
	}

	public String getProductInfo() {
		return "Oracle DB Version 11g";
	}

}
