package interfaces;

public class Main {

	public static void main(String[] args) {
		
		Connection con=COnFactory.getConnection("mysql");
		
		System.out.println(con.getConnection());
		System.out.println(con.getProductInfo());

	}

}
