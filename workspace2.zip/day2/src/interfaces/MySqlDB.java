package interfaces;

public class MySqlDB implements Connection{

	@Override
	public String getConnection() {
		
		return "MySQL DB connected..";
	}

	@Override
	public String getProductInfo() {
		// TODO Auto-generated method stub
		return "MYSQL version 6.0.1";
	}

}
