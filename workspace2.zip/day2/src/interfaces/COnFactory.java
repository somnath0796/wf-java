package interfaces;

public class COnFactory {

	public static Connection getConnection(String db) {
		if (db.equals("oracle")) {
			return new OracleDB();
		}
		if (db.equals("mysql")) {
			return new MySqlDB();
		} else {
			return null;
		}

	}
}
