package interfaces;

public interface Connection {

	public String getConnection();

	public String getProductInfo();
}
