package inheritance;

public class B extends A{
	public B(int x){
		System.out.println("B's Constructor");
	}
}
