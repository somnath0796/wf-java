package inheritance;

public class App1 {

	public static void main(String[] args) {
		Employee e= new Employee(100, "Raju", 45000);
		
		//System.out.println(e.getDetails());
		Person x= new TraineeEmp(1, "Kiran", 34000, "Good");
		System.out.println(x.getDetails());
		
		System.out.println(x);
	}

}
