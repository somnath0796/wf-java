package inheritance;

public class C extends B {
	public C(){
		super(30);
		System.out.println("C's Constructor");
	}
}
