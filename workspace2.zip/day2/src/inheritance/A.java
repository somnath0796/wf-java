package inheritance;

public class A {

	public A(){
		System.out.println("A's Constructor");
	}
}
