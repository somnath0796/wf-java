package io;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

import com.demo.wf.User;

public class SerializerDemo {

	public static void main(String[] args) throws Exception{
		FileOutputStream fos= new FileOutputStream("users.ser");
		ObjectOutputStream oos= new ObjectOutputStream(fos);
		
		User u= new User(100,"Kirti","Delhi");
		oos.writeObject(u);

	}

}
