package io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReader2 {

	public static void main(String[] args) {
		FileReader fis = null;
		FileWriter fos = null;
		BufferedReader br=null;
		BufferedWriter bw=null;
		try {
			fis = new FileReader("c:\\temp\\demo.txt");
			br=new BufferedReader(fis);
			fos=new FileWriter("c:\\temp\\demo_2.txt");
			bw= new BufferedWriter(fos);
			int data = 0;
			while ((data = br.read()) != -1) {
				bw.write(data);
				System.out.print((char) data);
			}
			bw.flush();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
				bw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
