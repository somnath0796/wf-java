package io;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import com.demo.wf.User;

public class DeserializerDemo {

	public static void main(String[] args) throws Exception {
		
		FileInputStream fis= new FileInputStream("users.ser");
		
		ObjectInputStream ois= new ObjectInputStream(fis);
		
		Object o=ois.readObject();
		
		User u=(User)o;
		
		System.out.println(u.getDetails());

	}

}
