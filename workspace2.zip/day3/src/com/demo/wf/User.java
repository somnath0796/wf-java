package com.demo.wf;

import java.io.Serializable;

public class User implements Serializable{
	int uid;
	String name;

	String city;

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public User(int uid, String name, String city) {
		this.uid = uid;
		this.name = name;
		this.city = city;
	}

	public String getDetails() {
		return uid + " " + name + " " + city;
	}
}
