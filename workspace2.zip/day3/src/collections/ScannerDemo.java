package collections;

import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter 1st Number : ");
		int a=sc.nextInt();
		
		System.out.println("Enter2nd Number : ");
		int b=sc.nextInt();
		
		System.out.println("The Sum of "+a+" and "+b+" = "+(a+b));
		
		System.out.println("Enter Your Name :");
		String name=sc.next();
		
		System.out.println("Your Name is "+name);

	}

}
