package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListDemo {

	public static void main(String[] args) {
		List<String> names=new ArrayList<String>();
		names.add("Ankur");
		names.add("Amit");
		names.add("Bikram");
		names.add("Cindy");
		names.add("Karan");
		names.add("Kiran");
		names.add("Sumit");
		names.add("Shivani");
		names.add("Zeeshan");
		names.add("Kiran");
		
		System.out.println(names.get(5));
		names.add(7, "Zaakir");
		System.out.println(names);
		
		Iterator<String> namesItr=names.iterator();
		while(namesItr.hasNext()){
			String name=namesItr.next();
			System.out.println(name+"--->"+name.length());
		}
		
		
		for(String s:names){
			System.out.println(s+"--->"+s.length());
		}
		

	}

}
