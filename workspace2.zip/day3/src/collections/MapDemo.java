package collections;

import java.util.HashMap;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		HashMap<String, String> codeMap = new HashMap<String, String>();
		
		codeMap.put("KA", "Karnataka");
		codeMap.put("KL", "Kerala");
		codeMap.put("TN", "Tamilnadu");
		codeMap.put("DL", "Delhi");
		codeMap.put("TS", "Telangana");
		codeMap.put("JH", "Jharkhand");
		codeMap.put("AP", "Andhra Pradesh");
		codeMap.put("UK", "Uttarakhand");
		
		System.out.println(codeMap.get("KL"));
		
		Set<String> keys=codeMap.keySet();
		
		for(String key:keys){
			System.out.println(key);
		}

	}

}
