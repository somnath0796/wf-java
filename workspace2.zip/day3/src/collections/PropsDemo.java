package collections;

import java.util.Properties;
import java.util.Set;

public class PropsDemo {

	public static void main(String[] args) {
		Properties props= new Properties();
		props.put("KA", "Karnataka");
		
		;
		
		
		System.setProperty("Trainer", "Shantanu");
		Properties sysprops=System.getProperties();
		//System.out.println(sysprops);
		
		Set<Object> keys=sysprops.keySet();
		for(Object o:keys){
			System.out.println(o+" = "+sysprops.get(o));
		}
		
		

	}

}
