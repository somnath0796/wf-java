package strings;

public class WrapperDemo {
	public static void main(String[] args) {
		
		int x=10;
		Integer y=x;
		int z=y;	
		
		String n1="30";
		
		int d=Integer.parseInt(n1);
		int e=Integer.parseInt("hello");
		
		
	}
}
