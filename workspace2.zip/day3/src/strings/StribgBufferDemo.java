package strings;

public class StribgBufferDemo {

	public static void main(String[] args) {
		
		//StringBuffer sb= new StringBuffer();
		StringBuilder sb= new StringBuilder();
		
		sb.append("This is a class of ").append("java").append(" at Alchemy");
		
		
		sb.insert(sb.indexOf("java")+"java".length()+1, "For Wells Fargo ");
		sb.replace(sb.indexOf("java"), sb.indexOf("java")+"java".length(), ".NET");
		
		String sub=sb.substring(10, 15);
		System.out.println(sub);
	}

}
