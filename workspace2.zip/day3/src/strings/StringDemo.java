package strings;

public class StringDemo {

	public static void main(String[] args) {
		String s1 = "hello";
		String s2 = "hello";
		String s3 = "hello";

		System.out.println(s1 == s2);
		System.out.println(s3 == s2);

		String s4 = new String("hello");
		String s5 = new String("hello");
		String s6 = new String("Hello");
		System.out.println(s4 == s5);

		String s7 = "This is a java class as java is a good programming language";

		String s8 = s1.intern();
		System.out.println(s8);
		System.out.println(s1 == s8);

		System.out.println(s6.equals(s5));
		System.out.println(s6.equalsIgnoreCase(s5));

		System.out.println(s7.indexOf("java"));
		System.out.println(s7.length());

		String[] words = s7.split(" ");
		int count = 0;
		for (int i = 0; i < words.length; i++) {

			if (words[i].equals("java")) {
				count++;
			}

		}

		System.out.println("Java Count : " + count);

	}

}
