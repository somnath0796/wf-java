
public class BoxDemo {

	public static void main(String[] args) {
		Box b = new Box(10,20,10);
		
		//b.length=30;
		
		System.out.println(b.getVolume());
		System.out.println(b.getColor());
		
		Box b1 = new Box(10,20,10,"Blue");
		
		System.out.println(b1.getVolume());
		System.out.println(b1.getColor());
		
		Box b2 = new Box(10,20,10,"Blue",6.2);
	}

}
