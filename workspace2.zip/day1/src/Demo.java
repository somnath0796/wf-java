
public class Demo {

	int x=10;
	public static void main(String[] args) {
	System.out.println("This is it!!");
	
	int x=20;
	double d=x;
	
	double d1=20.03;
	int y=(int)d1;
	System.out.println(y);
	}
	
	
	class A{
		int y=20;
	public void print(){
		System.out.println(x);
	}
	}
	
	public void doPrint(){
		System.out.println();
	}
	
	
}
