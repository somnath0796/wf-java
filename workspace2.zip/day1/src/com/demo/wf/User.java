package com.demo.wf;
public class User {
	int uid;
	String name;
	String city;
	
		
	public User(int uid, String name, String city) {
		this.uid = uid;
		this.name = name;
		this.city = city;
	}




	public String getDetails(){
		return uid+" "+name+" "+city;
	}
}
