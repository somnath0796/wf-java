
public class DuckDemo {

	public static void main(String[] args) {
		
		Duck d1= new Duck();
		Duck d2= new Duck();
		Duck d3= new Duck();
		Duck d4= new Duck();
		Duck d5= new Duck();
		
		System.out.println(Duck.duckCount);

	}

}
