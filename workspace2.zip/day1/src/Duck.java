
public class Duck {
	static int duckCount = 0;
	private String name="";

	public Duck() {
		duckCount++;
	}
	
}
