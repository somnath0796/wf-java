
public class OverloadDemo {
	
	static{
		
		System.out.println("This is static block");
	}

	static public void add(){
		System.out.println("No data to add...");
	}
	
	public int add(int a, int b){
		System.out.println("int,int is called..");
		return a+b;
	}
	
	public float add(int a, float b){
		System.out.println("int,float is called..");
		return a+b;
	}
	public double add(double a, double b){
		System.out.println("double,double is called..");
		return a+b;
	}
	
	public static void main(String[] args) {
		
		OverloadDemo o= new OverloadDemo();
		OverloadDemo o1= new OverloadDemo();
		OverloadDemo o2= new OverloadDemo();
		
	}

}
