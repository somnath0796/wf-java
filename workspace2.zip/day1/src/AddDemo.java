
public class AddDemo {

	public static void main(String[] args) {
		MyMath m=new MyMath();
		
		int x=m.add(20, 30);
		System.out.println(x);
	}

}
