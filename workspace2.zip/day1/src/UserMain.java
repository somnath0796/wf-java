import com.demo.wf.User;

public class UserMain {

	public static void main(String[] args) {
		User[] users= new User[5];
		
		users[0]=new User(100,"Baker","Bangalore");
		users[1]=new User(101,"James","Hyderabad");
		users[2]=new User(102,"Chethan","Bangalore");
		users[3]=new User(103,"Kiran","Chennai");
		users[4]=new User(104,"Amith","Delhi");
		
		
		for(int i=0;i<users.length;i++){
			System.out.println(users[i].getDetails());
		}

	}

}
